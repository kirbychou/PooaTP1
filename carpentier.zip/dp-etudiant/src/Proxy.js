/**
 * Created by Lucie on 11/09/2015.
 */
var Contact = Contact || {};
Contact = (function (self) {
    "use strict";
    self.ProxyCache = function (tableauContact) {
        var tableauProxy = [];
        var init = function (tableauContact) {

            tableauProxy = tableauContact;


        };
        var cache = [];
        this.search = function (strategie) {
            var resultat = null;
            for (var iter in tableauProxy) {
                resultat = strategie.search(tableauProxy[iter].list());

                if (resultat !== null) {
                    cache.push(strategie);
                    return resultat;
                }
            }
            return null;
        };

        this.inCache = function (strategie) {
            for (var iter =0; iter<cache.length; iter++) {
                if (cache[iter] === strategie) {
                    return true;
                }
            }
        return false;
    };
    init(tableauContact);
};
return self;
}
(Contact || {})
)
;